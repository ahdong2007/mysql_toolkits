############################################################################
# Test streaming in the TAR format
############################################################################

stream_extract_cmd="$TAR -ixvf"

stream_format=tar

. inc/xb_stream_common.sh
